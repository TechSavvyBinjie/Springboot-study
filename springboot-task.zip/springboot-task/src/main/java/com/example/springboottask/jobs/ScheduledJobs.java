package com.example.springboottask.jobs;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ScheduledJobs {
//    @Scheduled(fixedRate = 3000)
//    public void fixedRateJob() throws InterruptedException{
//        log.info("fixRate start:{}",new Date());
//        Thread.sleep(5000);
//        log.info("fixRate start:{}",new Date());
//
//    }
//    @Scheduled(fixedDelay = 5000)
//    public void fixedRateJob() throws InterruptedException{
//        log.info("fixDelay start:{}",new Date());
//        Thread.sleep(5000);
//        log.info("fixDelay start:{}",new Date());
//
//    }
//@Scheduled(cron = "0/10 * * * * ?")
//public void fixedRateJob() throws InterruptedException{
//    log.info("---------------cron 执行:{}",new Date());
//}
}
