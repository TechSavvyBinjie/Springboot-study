package com.example.mybatis_plus_study;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisPlusStudyApplicationTests {

    @Test
    void contextLoads() {
    }

}
