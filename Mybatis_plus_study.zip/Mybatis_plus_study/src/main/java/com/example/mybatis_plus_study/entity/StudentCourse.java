package com.example.mybatis_plus_study.entity;

import lombok.Data;

@Data
public class StudentCourse {
    private Long studentId;
    private Long courseId;
}