package com.example.mybatis_plus_study.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.mybatis_plus_study.entity.Course;

public interface CourseMapper extends BaseMapper<Course> {

}
