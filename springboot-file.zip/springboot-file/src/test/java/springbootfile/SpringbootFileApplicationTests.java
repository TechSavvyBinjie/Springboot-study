package springbootfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootFileApplicationTests {

    @Test
    void contextLoads() {
    }

}
